import { useState } from "react";
import { CloudBg } from "@/components/CloudBg";
import { Home } from "@/pages/Home";
import { AlphaGame } from "@/pages/AlphaGame";
import { MissingGame } from "@/pages/MissingGame";
import { MatchGame } from "@/pages/MatchGame";
import { SentenceGame } from "@/pages/SentenceGame";
import { ScrambleGame } from "@/pages/ScrambleGame";
import { Dashboard } from "@/pages/Dashboard";
import { AnimatePresence, motion } from "framer-motion";
import { useBackgroundMusic } from "@/hooks/useBackgroundMusic";
import { useSessionTracker } from "@/hooks/useSessionTracker";

export type Screen = "home" | "alpha" | "missing" | "match" | "sentence" | "scramble" | "dashboard";

function App() {
  const [screen, setScreen] = useState<Screen>("home");
  const [score, setScore] = useState(0);
  const { playing, toggle } = useBackgroundMusic();

  // Track time spent playing — persists to localStorage across sessions
  useSessionTracker();

  const addScore = () => setScore(s => s + 1);

  return (
    <div className="min-h-[100dvh] w-full relative overflow-hidden flex flex-col font-sans">
      <CloudBg />

      <main className="flex-1 w-full h-full flex flex-col relative z-10 overflow-y-auto">
        <AnimatePresence mode="wait">
          {screen === "home" && (
            <Home key="home" onPlay={setScreen} score={score} />
          )}
          {screen === "alpha" && (
            <AlphaGame key="alpha" onHome={() => setScreen("home")} score={score} />
          )}
          {screen === "missing" && (
            <MissingGame key="missing" onHome={() => setScreen("home")} score={score} onWin={addScore} />
          )}
          {screen === "match" && (
            <MatchGame key="match" onHome={() => setScreen("home")} score={score} onWin={addScore} />
          )}
          {screen === "sentence" && (
            <SentenceGame key="sentence" onHome={() => setScreen("home")} score={score} onWin={addScore} />
          )}
          {screen === "scramble" && (
            <ScrambleGame key="scramble" onHome={() => setScreen("home")} score={score} onWin={addScore} />
          )}
          {screen === "dashboard" && (
            <Dashboard key="dashboard" onBack={() => setScreen("home")} score={score} />
          )}
        </AnimatePresence>
      </main>

      <motion.button
        data-testid="button-music-toggle"
        onClick={toggle}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        title={playing ? "Mute music" : "Play music"}
        className={`fixed bottom-5 right-5 z-50 w-14 h-14 rounded-full border-4 border-white shadow-lg text-2xl flex items-center justify-center transition-colors ${
          playing ? "bg-green-400" : "bg-slate-400"
        }`}
      >
        {playing ? "🎵" : "🔇"}
      </motion.button>
    </div>
  );
}

export default App;
