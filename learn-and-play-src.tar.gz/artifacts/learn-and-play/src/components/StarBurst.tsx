import { motion, AnimatePresence } from "framer-motion";
import { useEffect, useState } from "react";

export function StarBurst({ active, onComplete }: { active: boolean; onComplete?: () => void }) {
  const [particles, setParticles] = useState<number[]>([]);

  useEffect(() => {
    if (active) {
      setParticles(Array.from({ length: 12 }, (_, i) => i));
      const timer = setTimeout(() => {
        setParticles([]);
        if (onComplete) onComplete();
      }, 1500);
      return () => clearTimeout(timer);
    }
  }, [active, onComplete]);

  return (
    <div className="fixed inset-0 pointer-events-none flex items-center justify-center z-50">
      <AnimatePresence>
        {particles.map((i) => {
          const angle = (i * 360) / 12;
          const velocity = 150 + Math.random() * 100;
          return (
            <motion.div
              key={i}
              initial={{ x: 0, y: 0, scale: 0, opacity: 1, rotate: 0 }}
              animate={{ 
                x: Math.cos((angle * Math.PI) / 180) * velocity,
                y: Math.sin((angle * Math.PI) / 180) * velocity,
                scale: Math.random() * 0.5 + 1,
                opacity: 0,
                rotate: 180 + Math.random() * 180
              }}
              exit={{ opacity: 0 }}
              transition={{ duration: 1 + Math.random() * 0.5, ease: "easeOut" }}
              className="absolute text-yellow-400 text-4xl"
            >
              ⭐
            </motion.div>
          );
        })}
      </AnimatePresence>
    </div>
  );
}
