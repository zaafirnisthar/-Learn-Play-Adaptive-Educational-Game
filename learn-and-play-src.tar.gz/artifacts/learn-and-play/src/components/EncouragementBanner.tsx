import { AnimatePresence, motion } from "framer-motion";
import { useEffect, useState } from "react";

interface Props {
  message: string;
  trigger: number;
}

export function EncouragementBanner({ message, trigger }: Props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!message) return;
    setVisible(true);
    const t = setTimeout(() => setVisible(false), 2200);
    return () => clearTimeout(t);
  }, [trigger, message]);

  const isBig = message.includes("MASTERED") || message.includes("UNSTOPPABLE") || message.includes("GENIUS") || message.includes("LEGENDARY") || message.includes("WOW");

  return (
    <AnimatePresence>
      {visible && (
        <motion.div
          key={trigger}
          initial={{ scale: 0, y: -30, opacity: 0 }}
          animate={{ scale: 1, y: 0, opacity: 1 }}
          exit={{ scale: 0.8, y: -20, opacity: 0 }}
          transition={{ type: "spring", bounce: 0.7, duration: 0.5 }}
          className={`fixed top-24 left-1/2 -translate-x-1/2 z-50 font-display whitespace-nowrap pointer-events-none ${
            isBig
              ? "bg-gradient-to-r from-yellow-400 to-orange-400 text-white text-3xl py-4 px-10 rounded-full shadow-2xl border-4 border-white"
              : "bg-yellow-400 text-yellow-900 text-2xl py-3 px-8 rounded-full shadow-lg border-4 border-white"
          }`}
        >
          {isBig && (
            <motion.span
              animate={{ rotate: [0, -5, 5, -5, 0] }}
              transition={{ duration: 0.5, repeat: 2 }}
              className="inline-block"
            >
              {message}
            </motion.span>
          )}
          {!isBig && message}
        </motion.div>
      )}
    </AnimatePresence>
  );
}
