import { motion } from "framer-motion";

export function CloudBg() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden z-[-1] sky-gradient">
      <motion.div
        animate={{ x: [0, 200, 0] }}
        transition={{ duration: 60, repeat: Infinity, ease: "linear" }}
        className="absolute top-[10%] left-[-10%] opacity-60"
      >
        <CloudSvg className="w-48 h-auto text-white" />
      </motion.div>
      <motion.div
        animate={{ x: [0, -150, 0] }}
        transition={{ duration: 75, repeat: Infinity, ease: "linear" }}
        className="absolute top-[30%] right-[-5%] opacity-70"
      >
        <CloudSvg className="w-64 h-auto text-white" />
      </motion.div>
      <motion.div
        animate={{ x: [0, 100, 0] }}
        transition={{ duration: 50, repeat: Infinity, ease: "linear" }}
        className="absolute bottom-[20%] left-[20%] opacity-50"
      >
        <CloudSvg className="w-32 h-auto text-white" />
      </motion.div>
    </div>
  );
}

function CloudSvg({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 24 24" fill="currentColor" className={className}>
      <path d="M17.5 19c2.48 0 4.5-2.02 4.5-4.5 0-2.33-1.78-4.25-4.05-4.48C17.3 7.6 14.88 6 12.25 6c-2.45 0-4.66 1.4-5.63 3.53C4.1 9.77 2 11.66 2 14c0 2.76 2.24 5 5 5h10.5z" />
    </svg>
  );
}
