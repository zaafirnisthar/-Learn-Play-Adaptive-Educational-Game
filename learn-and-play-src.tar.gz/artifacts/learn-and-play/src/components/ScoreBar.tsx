import { motion } from "framer-motion";
import { Star } from "lucide-react";

export function ScoreBar({ score, onHome }: { score: number; onHome: () => void }) {
  return (
    <div className="absolute top-4 left-0 right-0 px-6 flex justify-between items-center z-10">
      <motion.button
        whileHover={{ scale: 1.05 }}
        whileTap={{ scale: 0.95 }}
        onClick={onHome}
        className="bg-white/80 backdrop-blur shadow-sm text-primary font-bold py-2 px-4 rounded-full border-2 border-white hover:bg-white transition-colors"
      >
        Home
      </motion.button>
      <motion.div 
        key={score}
        initial={{ scale: 1.5, rotate: 10 }}
        animate={{ scale: 1, rotate: 0 }}
        className="bg-yellow-400 text-yellow-900 border-4 border-white shadow-md rounded-full px-5 py-2 flex items-center gap-2 font-display text-xl"
      >
        <Star className="w-6 h-6 fill-yellow-100 text-yellow-100" />
        <span>{score}</span>
      </motion.div>
    </div>
  );
}
