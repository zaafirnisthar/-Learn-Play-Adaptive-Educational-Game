import { useCallback } from "react";

const MASTERY_STREAK = 3;

export interface ItemStats {
  attempts: number;
  errors: number;
  streak: number;
  mastered: boolean;
  nextDue: number; // timestamp — spaced repetition due date
}

export interface GameSummary {
  namespace: string;
  label: string;
  emoji: string;
  accuracy: number;
  masteredCount: number;
  totalItems: number;
  totalAttempts: number;
  weakItems: Array<{ key: string; errors: number; attempts: number }>;
  masteredItems: string[];
}

function loadStats(ns: string): Record<string, ItemStats> {
  try {
    return JSON.parse(localStorage.getItem(`adaptive:${ns}`) ?? "{}");
  } catch { return {}; }
}

function saveStats(ns: string, stats: Record<string, ItemStats>) {
  try { localStorage.setItem(`adaptive:${ns}`, JSON.stringify(stats)); } catch {}
}

// Spaced repetition interval in ms: grows with streak (2h → 4h → 8h → 24h → 72h)
function nextInterval(streak: number): number {
  const hours = Math.min(Math.pow(2, streak) * 2, 72);
  return hours * 3_600_000;
}

const ENCOURAGEMENT: Record<number, string[]> = {
  1: ["Great job! ⭐", "You got it! 🎉", "Awesome! 👏", "Brilliant! 💡", "Perfect! ✨", "Wonderful! 🌟"],
  2: ["Two in a row! 🔥", "Keep going! 💪", "You're amazing! 🌈", "Super smart! 🦋"],
  3: ["Hat trick! 🎩✨", "On fire! 🔥🔥", "Incredible! 🏆", "Three in a row! 🌟🌟🌟"],
  5: ["UNSTOPPABLE! 🚀", "GENIUS! 🧠✨", "LEGENDARY! 👑", "WOW!! 🤩🤩🤩"],
};

function pickEncouragement(streak: number, masteryAchieved: boolean): string {
  if (masteryAchieved) {
    const opts = ["MASTERED! 🏅 Expert level!", "You're a STAR! 🌟 MASTERED!", "CHAMPION! 🏆 Word mastered!"];
    return opts[Math.floor(Math.random() * opts.length)];
  }
  const tier = streak >= 5 ? 5 : streak >= 3 ? 3 : streak >= 2 ? 2 : 1;
  const msgs = ENCOURAGEMENT[tier];
  return msgs[Math.floor(Math.random() * msgs.length)];
}

export function useAdaptive(namespace: string) {
  // Weighted selection using spaced repetition: due items surface first,
  // mastered + not-due items shown rarely, unseen items get priority
  const selectItem = useCallback(<T>(items: T[], keyFn: (item: T) => string): T => {
    const stats = loadStats(namespace);
    const now = Date.now();
    const weights = items.map(item => {
      const s = stats[keyFn(item)];
      if (!s) return 4; // unseen → highest priority
      if (now >= s.nextDue) return 3 + s.errors * 0.5; // due for review
      if (s.mastered) return 0.1; // mastered + not due → rare
      return 1 + s.errors * 0.8; // not mastered, still in interval
    });
    const total = weights.reduce((a, b) => a + b, 0);
    let r = Math.random() * total;
    for (let i = 0; i < items.length; i++) {
      r -= weights[i];
      if (r <= 0) return items[i];
    }
    return items[items.length - 1];
  }, [namespace]);

  const recordResult = useCallback((key: string, correct: boolean) => {
    const stats = loadStats(namespace);
    const prev = stats[key] ?? { attempts: 0, errors: 0, streak: 0, mastered: false, nextDue: 0 };
    const newStreak = correct ? prev.streak + 1 : 0;
    const masteryAchieved = !prev.mastered && newStreak >= MASTERY_STREAK;
    stats[key] = {
      attempts: prev.attempts + 1,
      errors: correct ? prev.errors : prev.errors + 1,
      streak: newStreak,
      mastered: prev.mastered || masteryAchieved,
      nextDue: correct ? Date.now() + nextInterval(newStreak) : Date.now(),
    };
    saveStats(namespace, stats);
    return {
      encouragement: correct ? pickEncouragement(newStreak, masteryAchieved) : "",
      masteryAchieved,
      streak: newStreak,
    };
  }, [namespace]);

  const isMastered = useCallback((key: string) => loadStats(namespace)[key]?.mastered ?? false, [namespace]);
  const getMasteredCount = useCallback(() => Object.values(loadStats(namespace)).filter(s => s.mastered).length, [namespace]);
  const getStats = useCallback((key: string): ItemStats => loadStats(namespace)[key] ?? { attempts: 0, errors: 0, streak: 0, mastered: false, nextDue: 0 }, [namespace]);

  return { selectItem, recordResult, isMastered, getMasteredCount, getStats };
}

// ── Global helpers used by Dashboard & Home ────────────────────────────────

const NS_META: Record<string, { label: string; emoji: string; totalItems: number }> = {
  missing:  { label: "Missing Letter",  emoji: "🔍", totalItems: 20 },
  match:    { label: "Match Objects",   emoji: "🧩", totalItems: 15 },
  sentence: { label: "Make a Sentence", emoji: "📝", totalItems: 10 },
  scramble: { label: "Word Scramble",   emoji: "🔀", totalItems: 20 },
};

export function getGameSummary(ns: string): GameSummary {
  const stats = loadStats(ns);
  const meta = NS_META[ns] ?? { label: ns, emoji: "🎮", totalItems: 10 };
  const entries = Object.entries(stats);
  const totalAttempts = entries.reduce((s, [, v]) => s + v.attempts, 0);
  const totalCorrect  = entries.reduce((s, [, v]) => s + (v.attempts - v.errors), 0);
  const accuracy = totalAttempts > 0 ? totalCorrect / totalAttempts : 0;
  const masteredCount = entries.filter(([, v]) => v.mastered).length;
  const weakItems = entries
    .filter(([, v]) => v.attempts > 0)
    .map(([key, v]) => ({ key, errors: v.errors, attempts: v.attempts }))
    .sort((a, b) => b.errors / b.attempts - a.errors / a.attempts)
    .slice(0, 6);
  const masteredItems = entries.filter(([, v]) => v.mastered).map(([k]) => k);
  return { namespace: ns, ...meta, accuracy, masteredCount, totalAttempts, weakItems, masteredItems };
}

export function getAllMasteredCount(): number {
  return Object.keys(NS_META).reduce((sum, ns) => sum + getGameSummary(ns).masteredCount, 0);
}

export function getTotalAttempts(): number {
  return Object.keys(NS_META).reduce((sum, ns) => sum + getGameSummary(ns).totalAttempts, 0);
}

export function getOverallAccuracy(): number {
  const summaries = Object.keys(NS_META).map(getGameSummary);
  const totalAtt = summaries.reduce((s, g) => s + g.totalAttempts, 0);
  const totalCor = summaries.reduce((s, g) => s + Math.round(g.accuracy * g.totalAttempts), 0);
  return totalAtt > 0 ? totalCor / totalAtt : 0;
}

// Returns the namespace of the game with lowest accuracy (most needing practice)
export function getRecommendedGame(): "missing" | "match" | "sentence" | "scramble" | null {
  const candidates = (["missing", "match", "sentence", "scramble"] as const)
    .map(ns => ({ ns, ...getGameSummary(ns) }))
    .filter(g => g.totalAttempts > 0);
  if (candidates.length === 0) return null;
  return candidates.sort((a, b) => a.accuracy - b.accuracy)[0].ns;
}
