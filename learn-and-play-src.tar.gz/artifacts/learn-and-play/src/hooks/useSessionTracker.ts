import { useEffect } from "react";

const STORAGE_KEY = "sessions:log";
const START_KEY = "session:startTime";

export interface SessionEntry {
  date: string; // YYYY-MM-DD
  seconds: number;
}

function today(): string {
  return new Date().toISOString().slice(0, 10);
}

function loadLog(): SessionEntry[] {
  try { return JSON.parse(localStorage.getItem(STORAGE_KEY) ?? "[]"); } catch { return []; }
}

function saveLog(log: SessionEntry[]) {
  try { localStorage.setItem(STORAGE_KEY, JSON.stringify(log.slice(-60))); } catch {} // keep 60 days max
}

function addSeconds(seconds: number) {
  if (seconds < 3) return; // ignore < 3s blips
  const log = loadLog();
  const d = today();
  const existing = log.find(e => e.date === d);
  if (existing) { existing.seconds += seconds; }
  else { log.push({ date: d, seconds }); }
  saveLog(log);
}

// Records session start on mount, saves duration on unmount
export function useSessionTracker() {
  useEffect(() => {
    const start = Date.now();
    localStorage.setItem(START_KEY, String(start));

    const handleUnload = () => {
      const elapsed = Math.round((Date.now() - start) / 1000);
      addSeconds(elapsed);
    };

    window.addEventListener("beforeunload", handleUnload);
    return () => {
      handleUnload();
      window.removeEventListener("beforeunload", handleUnload);
    };
  }, []);
}

// Snapshot current session time into log (call when opening dashboard mid-session)
export function flushCurrentSession() {
  const start = Number(localStorage.getItem(START_KEY) ?? 0);
  if (!start) return;
  const elapsed = Math.round((Date.now() - start) / 1000);
  addSeconds(elapsed);
  // Reset start so we don't double-count
  localStorage.setItem(START_KEY, String(Date.now()));
}

// ── Read helpers ─────────────────────────────────────────────────────────────

export function getSessionLog(): SessionEntry[] { return loadLog(); }

export function getTodaySeconds(): number {
  return loadLog().find(e => e.date === today())?.seconds ?? 0;
}

// Returns last N days as {date, seconds} including 0-second days
export function getWeekData(days = 7): SessionEntry[] {
  const log = loadLog();
  const result: SessionEntry[] = [];
  for (let i = days - 1; i >= 0; i--) {
    const d = new Date();
    d.setDate(d.getDate() - i);
    const dateStr = d.toISOString().slice(0, 10);
    result.push({ date: dateStr, seconds: log.find(e => e.date === dateStr)?.seconds ?? 0 });
  }
  return result;
}

// Longest streak of consecutive days with any practice
export function getLongestStreak(): number {
  const log = loadLog().filter(e => e.seconds > 0).map(e => e.date).sort();
  if (log.length === 0) return 0;
  let best = 1, cur = 1;
  for (let i = 1; i < log.length; i++) {
    const prev = new Date(log[i - 1]);
    const curr = new Date(log[i]);
    const diff = (curr.getTime() - prev.getTime()) / 86_400_000;
    cur = diff === 1 ? cur + 1 : 1;
    if (cur > best) best = cur;
  }
  return best;
}

export function formatTime(seconds: number): string {
  if (seconds < 60) return `${seconds}s`;
  const m = Math.floor(seconds / 60);
  const s = seconds % 60;
  return s > 0 ? `${m}m ${s}s` : `${m}m`;
}
