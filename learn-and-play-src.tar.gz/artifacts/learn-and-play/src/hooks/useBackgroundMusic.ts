import { useCallback, useEffect, useRef, useState } from "react";

const NOTES = [261, 294, 330, 392, 440, 392, 330, 294, 261, 294, 330, 392, 440, 523, 494, 440];
const NOTE_DURATION = 0.22;
const NOTE_GAP = 0.04;
const STEP = NOTE_DURATION + NOTE_GAP;
const VOLUME = 0.10;

export function useBackgroundMusic() {
  const [playing, setPlaying] = useState(false);
  const ctxRef = useRef<AudioContext | null>(null);
  const gainRef = useRef<GainNode | null>(null);
  const schedulerRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const nextNoteTimeRef = useRef(0);
  const noteIdxRef = useRef(0);
  const activeOscRef = useRef<OscillatorNode[]>([]);

  const scheduleNote = useCallback((freq: number, when: number) => {
    const ctx = ctxRef.current;
    const master = gainRef.current;
    if (!ctx || !master) return;

    const osc = ctx.createOscillator();
    const env = ctx.createGain();

    osc.type = "sine";
    osc.frequency.value = freq;

    env.gain.setValueAtTime(0, when);
    env.gain.linearRampToValueAtTime(VOLUME, when + 0.02);
    env.gain.setValueAtTime(VOLUME, when + NOTE_DURATION - 0.05);
    env.gain.linearRampToValueAtTime(0, when + NOTE_DURATION);

    osc.connect(env);
    env.connect(master);
    osc.start(when);
    osc.stop(when + NOTE_DURATION);

    activeOscRef.current.push(osc);
    osc.onended = () => {
      activeOscRef.current = activeOscRef.current.filter(o => o !== osc);
    };
  }, []);

  const stopAll = useCallback(() => {
    if (schedulerRef.current) {
      clearInterval(schedulerRef.current);
      schedulerRef.current = null;
    }
    activeOscRef.current.forEach(o => {
      try { o.stop(); } catch {}
    });
    activeOscRef.current = [];
  }, []);

  const startScheduler = useCallback(() => {
    const ctx = ctxRef.current;
    if (!ctx) return;
    nextNoteTimeRef.current = ctx.currentTime + 0.1;

    schedulerRef.current = setInterval(() => {
      const lookahead = 0.25;
      while (nextNoteTimeRef.current < ctx.currentTime + lookahead) {
        const freq = NOTES[noteIdxRef.current % NOTES.length];
        scheduleNote(freq, nextNoteTimeRef.current);
        nextNoteTimeRef.current += STEP;
        noteIdxRef.current++;
      }
    }, 50);
  }, [scheduleNote]);

  const toggle = useCallback(() => {
    setPlaying(prev => {
      const next = !prev;
      if (next) {
        try {
          if (!ctxRef.current) {
            const ctx = new AudioContext();
            ctxRef.current = ctx;
            const master = ctx.createGain();
            master.gain.value = 1;
            master.connect(ctx.destination);
            gainRef.current = master;
          } else if (ctxRef.current.state === "suspended") {
            ctxRef.current.resume();
          }
          startScheduler();
        } catch {
          return false;
        }
      } else {
        stopAll();
      }
      return next;
    });
  }, [startScheduler, stopAll]);

  useEffect(() => {
    return () => {
      stopAll();
      ctxRef.current?.close().catch(() => {});
    };
  }, [stopAll]);

  return { playing, toggle };
}
