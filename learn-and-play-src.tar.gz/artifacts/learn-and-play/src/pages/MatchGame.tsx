import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { ScoreBar } from "@/components/ScoreBar";
import { StarBurst } from "@/components/StarBurst";
import { EncouragementBanner } from "@/components/EncouragementBanner";
import { matchPairs } from "@/data/gameData";
import { useSpeech } from "@/hooks/useSpeech";
import { useAdaptive } from "@/hooks/useAdaptive";
import { Volume2 } from "lucide-react";

export function MatchGame({ onHome, score, onWin }: { onHome: () => void; score: number; onWin: () => void }) {
  const [round, setRound] = useState(0);
  const [target, setTarget] = useState(matchPairs[0]);
  const [options, setOptions] = useState<typeof matchPairs>([]);
  const [solved, setSolved] = useState(false);
  const [wrongId, setWrongId] = useState<string | null>(null);
  const [encouragement, setEncouragement] = useState("");
  const [encourageTrigger, setEncourageTrigger] = useState(0);
  const { speak } = useSpeech();
  const { selectItem, recordResult, isMastered } = useAdaptive("match");

  useEffect(() => { initRound(); }, [round]);

  const initRound = () => {
    const t = selectItem(matchPairs, p => p.word);
    setTarget(t);
    const others = matchPairs.filter(p => p.word !== t.word).sort(() => 0.5 - Math.random()).slice(0, 3);
    setOptions([t, ...others].sort(() => 0.5 - Math.random()));
    setSolved(false);
    setWrongId(null);
  };

  const handleGuess = (item: typeof matchPairs[0]) => {
    if (solved) return;
    if (item.word === target.word) {
      setSolved(true);
      onWin();
      const { encouragement: msg } = recordResult(target.word, true);
      setEncouragement(msg);
      setEncourageTrigger(t => t + 1);
      speak(`Yay! You found the ${target.word.toLowerCase()}!`);
    } else {
      recordResult(target.word, false);
      setWrongId(item.word);
      setTimeout(() => setWrongId(null), 500);
      speak(`That's a ${item.word.toLowerCase()}. Try again!`);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, x: -50 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: 50 }}
      className="flex flex-col items-center flex-1 pt-24 pb-6 px-4"
    >
      <ScoreBar score={score} onHome={onHome} />
      <StarBurst active={solved} />
      <EncouragementBanner message={encouragement} trigger={encourageTrigger} />

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-3xl gap-8">
        <div className="bg-white/80 border-4 border-orange-300 rounded-3xl p-6 flex flex-col items-center justify-center shadow-md w-full max-w-md relative">
          {isMastered(target.word) && (
            <span className="absolute top-3 right-4 text-2xl" title="Mastered!">🏅</span>
          )}
          <p className="text-xl font-bold text-orange-600 mb-2 uppercase tracking-wider">Find this:</p>
          <div className="text-5xl font-display text-gray-800 flex items-center gap-4">
            <span className="text-6xl">{target.emoji}</span> {target.word}
          </div>
          <button
            onClick={() => speak(`Find the ${target.word.toLowerCase()}`)}
            className="mt-4 bg-orange-100 hover:bg-orange-200 text-orange-700 py-2 px-6 rounded-full flex items-center gap-2 font-bold transition-colors"
          >
            <Volume2 size={20} /> Listen
          </button>
        </div>

        <div className="grid grid-cols-2 gap-4 w-full">
          {options.map((item, i) => {
            const isWrong = wrongId === item.word;
            return (
              <motion.button
                key={`${round}-${i}`}
                animate={isWrong ? { x: [-10, 10, -10, 10, 0] } : {}}
                whileHover={{ scale: 1.05 }}
                whileTap={{ scale: 0.95 }}
                onClick={() => handleGuess(item)}
                className={`bg-white rounded-3xl p-6 shadow-[0_8px_0_rgba(251,146,60,1)] border-4 ${
                  solved && item.word === target.word
                    ? "border-green-400 bg-green-50 shadow-[0_8px_0_rgba(74,222,128,1)]"
                    : isWrong ? "border-red-400" : "border-orange-400 hover:bg-orange-50"
                } flex flex-col items-center justify-center gap-2 transition-colors`}
              >
                <span className="text-7xl">{item.emoji}</span>
              </motion.button>
            );
          })}
        </div>

        {solved && (
          <motion.button
            initial={{ scale: 0 }} animate={{ scale: 1 }}
            whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            onClick={() => setRound(r => r + 1)}
            className="bg-green-400 text-white text-3xl font-display py-4 px-12 rounded-full shadow-[0_6px_0_rgba(22,163,74,1)] border-4 border-white mt-4"
          >
            Play Again! ➔
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
