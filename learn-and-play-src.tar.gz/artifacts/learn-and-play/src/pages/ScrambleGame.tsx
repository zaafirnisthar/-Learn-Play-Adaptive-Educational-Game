import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ScoreBar } from "@/components/ScoreBar";
import { StarBurst } from "@/components/StarBurst";
import { EncouragementBanner } from "@/components/EncouragementBanner";
import { missingWords } from "@/data/gameData";
import { useSpeech } from "@/hooks/useSpeech";
import { useAdaptive } from "@/hooks/useAdaptive";
import { Delete, Volume2 } from "lucide-react";

interface LetterTile { id: string; letter: string; used: boolean; }

function scramble(word: string): LetterTile[] {
  const letters = word.split("");
  // Ensure scrambled order differs from original for short words
  for (let i = letters.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [letters[i], letters[j]] = [letters[j], letters[i]];
  }
  // If still same as original, swap first two
  if (letters.join("") === word && letters.length >= 2) {
    [letters[0], letters[1]] = [letters[1], letters[0]];
  }
  return letters.map((l, i) => ({ id: `${l}-${i}`, letter: l, used: false }));
}

export function ScrambleGame({ onHome, score, onWin }: { onHome: () => void; score: number; onWin: () => void }) {
  const [round, setRound] = useState(0);
  const [wordData, setWordData] = useState(missingWords[0]);
  const [tiles, setTiles] = useState<LetterTile[]>([]);
  const [selected, setSelected] = useState<LetterTile[]>([]);
  const [solved, setSolved] = useState(false);
  const [wrongShake, setWrongShake] = useState(false);
  const [encouragement, setEncouragement] = useState("");
  const [encourageTrigger, setEncourageTrigger] = useState(0);
  const { speak } = useSpeech();
  const { selectItem, recordResult, isMastered } = useAdaptive("scramble");

  useEffect(() => { initRound(); }, [round]);

  const initRound = () => {
    const w = selectItem(missingWords, w => w.word);
    setWordData(w);
    setTiles(scramble(w.word));
    setSelected([]);
    setSolved(false);
  };

  const handleTileClick = (tile: LetterTile) => {
    if (tile.used || solved) return;
    const newSelected = [...selected, tile];
    setTiles(prev => prev.map(t => t.id === tile.id ? { ...t, used: true } : t));
    setSelected(newSelected);

    if (newSelected.length === wordData.word.length) {
      const attempt = newSelected.map(t => t.letter).join("");
      if (attempt === wordData.word) {
        setSolved(true);
        onWin();
        const { encouragement: msg } = recordResult(wordData.word, true);
        setEncouragement(msg);
        setEncourageTrigger(t => t + 1);
        speak(`Well done! The word is ${wordData.word.toLowerCase()}!`);
      } else {
        recordResult(wordData.word, false);
        setWrongShake(true);
        setTimeout(() => {
          setWrongShake(false);
          setTiles(scramble(wordData.word));
          setSelected([]);
          speak("Not quite — try again!");
        }, 700);
      }
    }
  };

  const handleDelete = () => {
    if (selected.length === 0 || solved) return;
    const last = selected[selected.length - 1];
    setTiles(prev => prev.map(t => t.id === last.id ? { ...t, used: false } : t));
    setSelected(prev => prev.slice(0, -1));
  };

  const handleClear = () => {
    if (solved) return;
    setTiles(scramble(wordData.word));
    setSelected([]);
  };

  const tileColor = (idx: number) => {
    const colors = ["bg-purple-400", "bg-pink-400", "bg-blue-400", "bg-teal-400", "bg-orange-400"];
    return colors[idx % colors.length];
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      className="flex flex-col items-center flex-1 pt-24 pb-6 px-4"
    >
      <ScoreBar score={score} onHome={onHome} />
      <StarBurst active={solved} />
      <EncouragementBanner message={encouragement} trigger={encourageTrigger} />

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-xl gap-6">

        {/* Word card */}
        <motion.div
          animate={wrongShake ? { x: [-12, 12, -12, 12, 0] } : {}}
          transition={{ duration: 0.5 }}
          className="bg-white border-8 border-purple-400 rounded-3xl p-8 flex flex-col items-center w-full shadow-lg relative"
        >
          {isMastered(wordData.word) && (
            <span className="absolute top-3 right-4 text-2xl">🏅</span>
          )}
          <div className="text-8xl mb-4">{wordData.emoji}</div>
          <p className="text-purple-500 font-display text-lg mb-4 uppercase tracking-widest">Unscramble!</p>

          {/* Answer slots */}
          <div className="flex gap-3 mb-2">
            {wordData.word.split("").map((_, i) => (
              <motion.div
                key={i}
                layout
                className={`w-16 h-20 flex items-center justify-center text-4xl font-display rounded-xl border-4 transition-all ${
                  selected[i]
                    ? solved
                      ? "bg-green-100 border-green-400 text-green-700"
                      : "bg-purple-100 border-purple-400 text-purple-700"
                    : "bg-gray-100 border-gray-300 border-dashed"
                }`}
              >
                {selected[i]?.letter ?? ""}
              </motion.div>
            ))}
          </div>

          <div className="flex gap-3 mt-3">
            <button
              onClick={() => speak(wordData.word.toLowerCase())}
              className="bg-blue-100 text-blue-600 font-bold py-2 px-4 rounded-full flex items-center gap-2 text-sm"
            >
              <Volume2 size={16} /> Hint
            </button>
            <button
              onClick={handleDelete}
              disabled={selected.length === 0 || solved}
              className="bg-gray-100 text-gray-600 font-bold py-2 px-4 rounded-full flex items-center gap-2 text-sm disabled:opacity-40"
            >
              <Delete size={16} /> Back
            </button>
            <button
              onClick={handleClear}
              disabled={solved}
              className="bg-red-100 text-red-500 font-bold py-2 px-4 rounded-full text-sm disabled:opacity-40"
            >
              Clear
            </button>
          </div>
        </motion.div>

        {/* Letter tiles */}
        {!solved ? (
          <div className="flex gap-4 flex-wrap justify-center">
            <AnimatePresence>
              {tiles.map((tile, i) => (
                <motion.button
                  key={tile.id}
                  layout
                  initial={{ scale: 0, rotate: -15 }}
                  animate={{ scale: tile.used ? 0.7 : 1, rotate: 0, opacity: tile.used ? 0.3 : 1 }}
                  whileHover={tile.used ? {} : { scale: 1.15, y: -8 }}
                  whileTap={tile.used ? {} : { scale: 0.9 }}
                  onClick={() => handleTileClick(tile)}
                  disabled={tile.used}
                  className={`${tileColor(i)} text-white text-5xl font-display w-20 h-24 rounded-2xl shadow-[0_6px_0_rgba(0,0,0,0.15)] border-4 border-white flex items-center justify-center transition-all`}
                >
                  {tile.letter}
                </motion.button>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <motion.button
            initial={{ scale: 0 }} animate={{ scale: 1 }}
            whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            onClick={() => setRound(r => r + 1)}
            className="bg-purple-400 text-white text-3xl font-display py-4 px-12 rounded-full shadow-[0_6px_0_rgba(139,92,246,1)] border-4 border-white"
          >
            Next Word! ➔
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
