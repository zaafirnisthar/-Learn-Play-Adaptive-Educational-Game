import { useMemo } from "react";
import { motion } from "framer-motion";
import { ArrowLeft, Star, Trophy, Target, TrendingUp, AlertCircle, CheckCircle, Clock, Flame } from "lucide-react";
import { getGameSummary, getOverallAccuracy, getAllMasteredCount, getTotalAttempts } from "@/hooks/useAdaptive";
import {
  flushCurrentSession,
  getTodaySeconds,
  getWeekData,
  getLongestStreak,
  formatTime,
} from "@/hooks/useSessionTracker";

interface Props {
  onBack: () => void;
  score: number;
}

const NAMESPACES = ["missing", "match", "sentence", "scramble"] as const;

const GAME_COLORS: Record<string, string> = {
  missing:  "border-teal-400 bg-teal-50",
  match:    "border-orange-400 bg-orange-50",
  sentence: "border-green-400 bg-green-50",
  scramble: "border-purple-400 bg-purple-50",
};

const BAR_COLORS: Record<string, string> = {
  missing:  "bg-teal-400",
  match:    "bg-orange-400",
  sentence: "bg-green-400",
  scramble: "bg-purple-400",
};

const DAY_LABELS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

function AccuracyBadge({ accuracy }: { accuracy: number }) {
  const pct = Math.round(accuracy * 100);
  const color = pct >= 80 ? "text-green-600 bg-green-100" : pct >= 50 ? "text-yellow-600 bg-yellow-100" : "text-red-500 bg-red-100";
  return <span className={`text-sm font-bold px-3 py-1 rounded-full ${color}`}>{pct}%</span>;
}

export function Dashboard({ onBack, score }: Props) {
  // Flush partial session so today's time is current
  useMemo(() => { flushCurrentSession(); }, []);

  const summaries = NAMESPACES.map(ns => getGameSummary(ns));
  const mastered = getAllMasteredCount();
  const attempts = getTotalAttempts();
  const accuracy = getOverallAccuracy();
  const todaySec = getTodaySeconds();
  const streak = getLongestStreak();
  const weekData = getWeekData(7);
  const maxSec = Math.max(...weekData.map(d => d.seconds), 60);

  const allWeak = summaries
    .flatMap(s => s.weakItems.map(w => ({ ...w, game: s.label, ns: s.namespace })))
    .sort((a, b) => b.errors / b.attempts - a.errors / a.attempts)
    .slice(0, 8);

  const allMastered = summaries.flatMap(s =>
    s.masteredItems.map(k => ({ key: k, game: s.label, ns: s.namespace }))
  );

  const todayIdx = new Date().getDay();

  return (
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -30 }}
      className="flex flex-col min-h-full w-full max-w-4xl mx-auto px-4 pt-6 pb-10 gap-6"
    >
      {/* Header */}
      <div className="flex items-center gap-4 pt-2">
        <motion.button
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
          onClick={onBack}
          className="bg-white border-4 border-blue-200 shadow rounded-full p-2 text-blue-500 hover:bg-blue-50 transition-colors"
        >
          <ArrowLeft size={24} />
        </motion.button>
        <div>
          <h1 className="text-3xl font-display text-white drop-shadow">Progress Report</h1>
          <p className="text-blue-700 font-bold text-sm">Parent &amp; Teacher View</p>
        </div>
      </div>

      {/* Overview cards */}
      <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
        {[
          { icon: <Star className="text-yellow-500" size={22} />, label: "Stars Earned",     value: score,                           color: "bg-yellow-50 border-yellow-300" },
          { icon: <Trophy className="text-amber-500" size={22} />, label: "Items Mastered",  value: mastered,                        color: "bg-amber-50 border-amber-300"  },
          { icon: <Target className="text-blue-500" size={22} />, label: "Total Attempts",   value: attempts,                        color: "bg-blue-50 border-blue-300"    },
          { icon: <TrendingUp className="text-green-500" size={22} />, label: "Accuracy",    value: `${Math.round(accuracy * 100)}%`, color: "bg-green-50 border-green-300"  },
          { icon: <Clock className="text-purple-500" size={22} />, label: "Today's Practice",value: formatTime(todaySec),            color: "bg-purple-50 border-purple-300"},
          { icon: <Flame className="text-red-500" size={22} />, label: "Best Streak",        value: `${streak} day${streak !== 1 ? "s" : ""}`, color: "bg-red-50 border-red-300" },
        ].map(({ icon, label, value, color }) => (
          <motion.div
            key={label}
            initial={{ scale: 0.8, opacity: 0 }} animate={{ scale: 1, opacity: 1 }}
            className={`${color} border-4 rounded-2xl p-4 flex flex-col items-center gap-1 shadow-sm`}
          >
            {icon}
            <span className="text-2xl font-display text-gray-800">{value}</span>
            <span className="text-xs font-bold text-gray-500 text-center">{label}</span>
          </motion.div>
        ))}
      </div>

      {/* Weekly Practice Chart */}
      <div className="bg-white/80 backdrop-blur border-4 border-white rounded-3xl p-5 shadow-sm">
        <h2 className="text-xl font-display text-gray-700 mb-4">📅 Daily Practice (Last 7 Days)</h2>
        <div className="flex items-end justify-between gap-2 h-32">
          {weekData.map((d, i) => {
            const dayName = DAY_LABELS[new Date(d.date + "T12:00:00").getDay()];
            const isToday = d.date === new Date().toISOString().slice(0, 10);
            const pct = d.seconds / maxSec;
            const minH = d.seconds > 0 ? 8 : 2;
            return (
              <div key={d.date} className="flex flex-col items-center gap-1 flex-1">
                {d.seconds > 0 && (
                  <span className="text-xs font-bold text-gray-500">{formatTime(d.seconds)}</span>
                )}
                <motion.div
                  initial={{ height: 0 }} animate={{ height: `${Math.max(pct * 100, minH)}%` }}
                  transition={{ duration: 0.7, ease: "easeOut", delay: i * 0.07 }}
                  className={`w-full rounded-t-xl ${
                    isToday ? "bg-purple-400" : d.seconds > 0 ? "bg-blue-300" : "bg-gray-200"
                  }`}
                  style={{ minHeight: minH }}
                />
                <span className={`text-xs font-bold ${isToday ? "text-purple-600" : "text-gray-400"}`}>
                  {dayName}
                </span>
              </div>
            );
          })}
        </div>
        {weekData.every(d => d.seconds === 0) && (
          <p className="text-center text-gray-400 text-sm mt-2 italic">Play some games to see daily practice here!</p>
        )}
      </div>

      {/* Per-game breakdown */}
      <div className="bg-white/80 backdrop-blur border-4 border-white rounded-3xl p-5 shadow-sm">
        <h2 className="text-xl font-display text-gray-700 mb-4">Game Breakdown</h2>
        <div className="flex flex-col gap-4">
          {summaries.map(s => {
            const pct = Math.round(s.accuracy * 100);
            const mastPct = s.totalItems > 0 ? Math.round(s.masteredCount / s.totalItems * 100) : 0;
            return (
              <div key={s.namespace} className={`border-4 rounded-2xl p-4 ${GAME_COLORS[s.namespace] ?? "border-gray-200 bg-gray-50"}`}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-2xl">{s.emoji}</span>
                    <span className="font-display text-gray-800">{s.label}</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs text-gray-500">{s.totalAttempts} tries</span>
                    {s.totalAttempts > 0 && <AccuracyBadge accuracy={s.accuracy} />}
                  </div>
                </div>
                {s.totalAttempts === 0 ? (
                  <p className="text-sm text-gray-400 italic">Not played yet</p>
                ) : (
                  <div className="flex flex-col gap-2">
                    <div>
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Accuracy</span><span>{pct}%</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <motion.div
                          initial={{ width: 0 }} animate={{ width: `${pct}%` }}
                          transition={{ duration: 0.8, ease: "easeOut" }}
                          className={`h-3 rounded-full ${BAR_COLORS[s.namespace] ?? "bg-gray-400"}`}
                        />
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs text-gray-500 mb-1">
                        <span>Mastered</span><span>{s.masteredCount} / {s.totalItems}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-3">
                        <motion.div
                          initial={{ width: 0 }} animate={{ width: `${mastPct}%` }}
                          transition={{ duration: 0.8, ease: "easeOut", delay: 0.2 }}
                          className="h-3 rounded-full bg-yellow-400"
                        />
                      </div>
                    </div>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      </div>

      {/* Needs Practice */}
      {allWeak.length > 0 && (
        <div className="bg-white/80 backdrop-blur border-4 border-red-200 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <AlertCircle className="text-red-400" size={22} />
            <h2 className="text-xl font-display text-gray-700">Needs More Practice</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {allWeak.map(w => {
              const acc = Math.round((1 - w.errors / w.attempts) * 100);
              return (
                <div key={`${w.ns}-${w.key}`} className="bg-red-50 border-2 border-red-200 rounded-xl px-3 py-2 flex items-center gap-2">
                  <span className="font-display text-gray-800">{w.key.length > 20 ? w.key.split(" ").slice(0, 2).join(" ") + "…" : w.key}</span>
                  <span className="text-xs bg-red-200 text-red-700 px-2 py-0.5 rounded-full font-bold">{acc}%</span>
                  <span className="text-xs text-gray-400">{w.game}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* Mastered items */}
      {allMastered.length > 0 && (
        <div className="bg-white/80 backdrop-blur border-4 border-yellow-200 rounded-3xl p-5 shadow-sm">
          <div className="flex items-center gap-2 mb-3">
            <CheckCircle className="text-yellow-500" size={22} />
            <h2 className="text-xl font-display text-gray-700">Mastered! 🏅</h2>
          </div>
          <div className="flex flex-wrap gap-2">
            {allMastered.map(m => (
              <div key={`${m.ns}-${m.key}`} className="bg-yellow-50 border-2 border-yellow-300 rounded-xl px-3 py-2 flex items-center gap-2">
                <span className="text-yellow-500">🏅</span>
                <span className="font-display text-gray-700">{m.key.length > 20 ? m.key.split(" ").slice(0, 2).join(" ") + "…" : m.key}</span>
                <span className="text-xs text-gray-400">{m.game}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {attempts === 0 && (
        <div className="text-center py-12">
          <p className="text-5xl mb-4">🎮</p>
          <p className="text-xl font-display text-white drop-shadow">No games played yet!</p>
          <p className="text-blue-700 font-bold mt-2">Play some games to see progress here.</p>
        </div>
      )}
    </motion.div>
  );
}
