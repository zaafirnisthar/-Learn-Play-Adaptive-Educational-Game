import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ScoreBar } from "@/components/ScoreBar";
import { EncouragementBanner } from "@/components/EncouragementBanner";
import { alphabet } from "@/data/gameData";
import { useSpeech } from "@/hooks/useSpeech";
import { useAdaptive } from "@/hooks/useAdaptive";
import { ChevronLeft, ChevronRight, Volume2 } from "lucide-react";

export function AlphaGame({ onHome, score }: { onHome: () => void; score: number }) {
  const [index, setIndex] = useState(0);
  const [practiceCount, setPracticeCount] = useState<Record<string, number>>({});
  const [encouragement, setEncouragement] = useState("");
  const [encourageTrigger, setEncourageTrigger] = useState(0);
  const { speak } = useSpeech();
  const { isMastered, recordResult } = useAdaptive("alpha");

  const current = alphabet[index];

  const handleNext = () => setIndex(prev => (prev + 1) % alphabet.length);
  const handlePrev = () => setIndex(prev => (prev - 1 + alphabet.length) % alphabet.length);

  const handleSpeak = () => {
    speak(`${current.letter} is for ${current.word}`);
    const count = (practiceCount[current.letter] ?? 0) + 1;
    setPracticeCount(p => ({ ...p, [current.letter]: count }));
    if (count % 3 === 0) {
      const { encouragement: msg } = recordResult(current.letter, true);
      setEncouragement(msg);
      setEncourageTrigger(t => t + 1);
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex flex-col items-center flex-1 pt-24 pb-6 px-4"
    >
      <ScoreBar score={score} onHome={onHome} />
      <EncouragementBanner message={encouragement} trigger={encourageTrigger} />

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-2xl gap-8">
        <div className="flex items-center justify-between w-full">
          <motion.button
            whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
            onClick={handlePrev}
            className="w-16 h-16 bg-white border-4 border-pink-300 rounded-full flex items-center justify-center text-pink-500 shadow-md"
          >
            <ChevronLeft size={32} />
          </motion.button>

          <AnimatePresence mode="wait">
            <motion.div
              key={current.letter}
              initial={{ scale: 0.5, opacity: 0, rotate: -10 }}
              animate={{ scale: 1, opacity: 1, rotate: 0, y: [0, -10, 0] }}
              exit={{ scale: 0.5, opacity: 0, rotate: 10 }}
              transition={{
                y: { repeat: Infinity, duration: 2, ease: "easeInOut" },
                default: { type: "spring", bounce: 0.5 }
              }}
              className="bg-white border-8 border-pink-400 rounded-[3rem] p-10 flex flex-col items-center justify-center shadow-[0_12px_0_rgba(244,114,182,0.3)] w-64 h-80 relative"
            >
              {isMastered(current.letter) && (
                <span className="absolute top-3 right-4 text-xl" title="Mastered!">🏅</span>
              )}
              <h2 className="text-8xl font-display text-pink-500 mb-4">{current.letter}</h2>
              <div className="text-7xl mb-2">{current.emoji}</div>
              <p className="text-2xl font-display text-gray-700">{current.word}</p>
            </motion.div>
          </AnimatePresence>

          <motion.button
            whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
            onClick={handleNext}
            className="w-16 h-16 bg-white border-4 border-pink-300 rounded-full flex items-center justify-center text-pink-500 shadow-md"
          >
            <ChevronRight size={32} />
          </motion.button>
        </div>

        <motion.button
          whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
          onClick={handleSpeak}
          className="bg-blue-400 text-white font-display text-2xl py-4 px-10 rounded-full shadow-[0_6px_0_rgba(59,130,246,0.8)] border-4 border-white flex items-center gap-3"
        >
          <Volume2 size={32} /> Say It
        </motion.button>
      </div>

      <div className="w-full max-w-4xl bg-white/60 p-4 rounded-3xl backdrop-blur flex flex-wrap justify-center gap-2 shadow-sm mt-8">
        {alphabet.map((item, i) => {
          const mastered = isMastered(item.letter);
          const practiced = (practiceCount[item.letter] ?? 0) > 0;
          return (
            <button
              key={item.letter}
              onClick={() => setIndex(i)}
              className={`w-10 h-10 rounded-full font-display text-xl transition-all relative ${
                i === index
                  ? "bg-pink-500 text-white shadow-md scale-110"
                  : mastered
                  ? "bg-yellow-300 text-yellow-900 shadow-sm"
                  : practiced
                  ? "bg-pink-100 text-pink-700"
                  : "bg-white text-gray-600 hover:bg-pink-100"
              }`}
            >
              {item.letter}
              {mastered && <span className="absolute -top-1 -right-1 text-xs">🏅</span>}
            </button>
          );
        })}
      </div>
    </motion.div>
  );
}
