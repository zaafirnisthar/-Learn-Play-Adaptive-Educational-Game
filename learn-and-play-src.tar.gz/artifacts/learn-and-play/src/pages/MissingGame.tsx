import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ScoreBar } from "@/components/ScoreBar";
import { StarBurst } from "@/components/StarBurst";
import { EncouragementBanner } from "@/components/EncouragementBanner";
import { missingWords } from "@/data/gameData";
import { useSpeech } from "@/hooks/useSpeech";
import { useAdaptive } from "@/hooks/useAdaptive";
import { Volume2 } from "lucide-react";

export function MissingGame({ onHome, score, onWin }: { onHome: () => void; score: number; onWin: () => void }) {
  const [round, setRound] = useState(0);
  const [wordData, setWordData] = useState(missingWords[0]);
  const [blankIndex, setBlankIndex] = useState(0);
  const [options, setOptions] = useState<string[]>([]);
  const [solved, setSolved] = useState(false);
  const [wrongShake, setWrongShake] = useState(false);
  const [encouragement, setEncouragement] = useState("");
  const [encourageTrigger, setEncourageTrigger] = useState(0);
  const { speak } = useSpeech();
  const { selectItem, recordResult, isMastered } = useAdaptive("missing");

  useEffect(() => { initRound(); }, [round]);

  const initRound = () => {
    const wordObj = selectItem(missingWords, w => w.word);
    setWordData(wordObj);
    const blank = Math.floor(Math.random() * wordObj.word.length);
    setBlankIndex(blank);
    const correctLetter = wordObj.word[blank];
    const wrongLetters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ".split("").filter(l => l !== correctLetter).sort(() => 0.5 - Math.random()).slice(0, 3);
    setOptions([correctLetter, ...wrongLetters].sort(() => 0.5 - Math.random()));
    setSolved(false);
  };

  const handleGuess = (letter: string) => {
    if (solved) return;
    if (letter === wordData.word[blankIndex]) {
      setSolved(true);
      onWin();
      const { encouragement: msg } = recordResult(wordData.word, true);
      setEncouragement(msg);
      setEncourageTrigger(t => t + 1);
      speak(`Correct! The letter is ${letter}. The word is ${wordData.word}!`);
    } else {
      recordResult(wordData.word, false);
      setWrongShake(true);
      setTimeout(() => setWrongShake(false), 500);
      speak("Oops, try again!");
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 1.1 }}
      className="flex flex-col items-center flex-1 pt-24 pb-6 px-4"
    >
      <ScoreBar score={score} onHome={onHome} />
      <StarBurst active={solved} />
      <EncouragementBanner message={encouragement} trigger={encourageTrigger} />

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-2xl gap-8">
        <motion.div
          animate={wrongShake ? { x: [-10, 10, -10, 10, 0] } : {}}
          transition={{ duration: 0.4 }}
          className="bg-white border-8 border-teal-400 rounded-3xl p-10 flex flex-col items-center justify-center shadow-lg w-full relative"
        >
          {isMastered(wordData.word) && (
            <span className="absolute top-3 right-4 text-2xl" title="Mastered!">🏅</span>
          )}
          <div className="text-8xl mb-6">{wordData.emoji}</div>
          <div className="flex gap-4 mb-6">
            {wordData.word.split("").map((char, i) => (
              <div
                key={i}
                className={`w-20 h-24 flex items-center justify-center text-6xl font-display rounded-xl border-4 ${
                  i === blankIndex
                    ? solved ? "bg-green-100 border-green-400 text-green-600" : "bg-teal-50 border-teal-300 text-transparent"
                    : "bg-gray-100 border-gray-300 text-gray-700"
                }`}
              >
                {i === blankIndex && !solved ? "_" : char}
              </div>
            ))}
          </div>
          <motion.button
            whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            onClick={() => speak(wordData.word)}
            className="bg-blue-100 text-blue-600 font-bold py-2 px-6 rounded-full flex items-center gap-2"
          >
            <Volume2 size={20} /> Hint
          </motion.button>
        </motion.div>

        {!solved ? (
          <div className="grid grid-cols-4 gap-4 w-full">
            {options.map((letter, i) => (
              <motion.button
                key={i}
                whileHover={{ scale: 1.1, y: -5 }} whileTap={{ scale: 0.9 }}
                onClick={() => handleGuess(letter)}
                className="bg-teal-400 text-white text-5xl font-display py-6 rounded-2xl shadow-[0_6px_0_rgba(13,148,136,1)] border-4 border-white"
              >
                {letter}
              </motion.button>
            ))}
          </div>
        ) : (
          <AnimatePresence>
            <motion.button
              initial={{ scale: 0 }} animate={{ scale: 1 }}
              whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
              onClick={() => setRound(r => r + 1)}
              className="bg-green-400 text-white text-3xl font-display py-4 px-12 rounded-full shadow-[0_6px_0_rgba(22,163,74,1)] border-4 border-white mt-4"
            >
              Next Word! ➔
            </motion.button>
          </AnimatePresence>
        )}
      </div>
    </motion.div>
  );
}
