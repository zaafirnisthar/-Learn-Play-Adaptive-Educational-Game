import { motion } from "framer-motion";
import { Star, BarChart2 } from "lucide-react";
import { getAllMasteredCount, getRecommendedGame } from "@/hooks/useAdaptive";
import type { Screen } from "@/App";

type HomeProps = {
  onPlay: (screen: Screen) => void;
  score: number;
};

const container = {
  hidden: { opacity: 0 },
  show: { opacity: 1, transition: { staggerChildren: 0.1 } }
};

const item = {
  hidden: { opacity: 0, y: 50, scale: 0.9 },
  show: { opacity: 1, y: 0, scale: 1, transition: { type: "spring", bounce: 0.5 } }
};

export function Home({ onPlay, score }: HomeProps) {
  const mastered = getAllMasteredCount();
  const recommended = getRecommendedGame();

  const GAMES: Array<{ id: Screen; title: string; emoji: string; color: string }> = [
    { id: "alpha",    title: "ABC Letters",    emoji: "🍎", color: "bg-pink-400"   },
    { id: "missing",  title: "Missing Letter", emoji: "🔍", color: "bg-teal-400"   },
    { id: "match",    title: "Match Objects",  emoji: "🧩", color: "bg-orange-400" },
    { id: "sentence", title: "Make a Sentence",emoji: "📝", color: "bg-green-400"  },
    { id: "scramble", title: "Word Scramble",  emoji: "🔀", color: "bg-purple-400" },
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      className="flex flex-col items-center justify-center flex-1 p-6 relative"
    >
      {/* Score badge */}
      <div className="absolute top-4 left-4 bg-yellow-400 text-yellow-900 border-4 border-white shadow-md rounded-full px-5 py-2 flex items-center gap-2 font-display text-xl">
        <Star className="w-6 h-6 fill-yellow-100 text-yellow-100" />
        <span>{score}</span>
      </div>

      {/* Mastered count */}
      {mastered > 0 && (
        <motion.div
          initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }}
          className="absolute top-4 right-20 bg-white/80 border-4 border-yellow-300 shadow-md rounded-full px-4 py-2 font-display text-base text-yellow-700"
        >
          🏅 {mastered} mastered
        </motion.div>
      )}

      {/* Parent/Teacher dashboard button */}
      <motion.button
        whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
        onClick={() => onPlay("dashboard")}
        data-testid="button-dashboard"
        className="absolute bottom-5 left-5 bg-white/80 border-4 border-blue-200 shadow-md rounded-full px-4 py-2 flex items-center gap-2 font-bold text-blue-600 text-sm hover:bg-white transition-colors"
      >
        <BarChart2 size={18} /> Progress Report
      </motion.button>

      {/* Title */}
      <motion.div
        initial={{ scale: 0, rotate: -10 }}
        animate={{ scale: 1, rotate: 0 }}
        transition={{ type: "spring", bounce: 0.6, delay: 0.2 }}
        className="mb-8 text-center"
      >
        <h1 className="text-5xl md:text-7xl font-display text-white drop-shadow-[0_4px_4px_rgba(0,0,0,0.1)] mb-2" style={{ WebkitTextStroke: "2px #4a90e2" }}>
          Learn & Play
        </h1>
        <p className="text-xl md:text-2xl text-blue-800 font-bold bg-white/50 inline-block px-6 py-2 rounded-full shadow-sm">
          Pick a game to start!
        </p>
        {score > 0 && (
          <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="mt-3 text-lg text-blue-700 font-bold">
            {score >= 10 ? "🌟 Amazing progress! Keep going!" : score >= 5 ? "🔥 You're on a roll!" : "⭐ Great start!"}
          </motion.p>
        )}
      </motion.div>

      {/* Game grid — 2 cols with scramble spanning full width on last row if odd */}
      <motion.div
        variants={container} initial="hidden" animate="show"
        className="grid grid-cols-2 gap-4 max-w-4xl w-full"
      >
        {GAMES.map(g => (
          <GameCard
            key={g.id}
            title={g.title}
            emoji={g.emoji}
            color={g.color}
            recommended={recommended === g.id}
            onClick={() => onPlay(g.id)}
            wide={g.id === "scramble"}
          />
        ))}
      </motion.div>
    </motion.div>
  );
}

function GameCard({
  title, emoji, color, recommended, onClick, wide
}: {
  title: string; emoji: string; color: string;
  recommended: boolean; onClick: () => void; wide?: boolean;
}) {
  return (
    <motion.button
      variants={item}
      whileHover={{ scale: 1.05, rotate: 1 }}
      whileTap={{ scale: 0.95 }}
      onClick={onClick}
      className={`${color} rounded-3xl p-6 shadow-[0_8px_0_rgba(0,0,0,0.1)] border-4 border-white flex flex-col items-center justify-center gap-3 text-white transition-colors relative ${wide ? "col-span-2" : ""}`}
    >
      {recommended && (
        <motion.div
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ repeat: Infinity, duration: 1.2 }}
          className="absolute -top-3 -right-2 bg-yellow-400 text-yellow-900 text-xs font-display px-3 py-1 rounded-full border-2 border-white shadow"
        >
          ⭐ Try this!
        </motion.div>
      )}
      <span className="text-5xl filter drop-shadow-md">{emoji}</span>
      <h2 className="text-xl md:text-2xl font-display text-center drop-shadow-md">{title}</h2>
    </motion.button>
  );
}
