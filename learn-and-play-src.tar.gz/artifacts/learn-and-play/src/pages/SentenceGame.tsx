import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ScoreBar } from "@/components/ScoreBar";
import { StarBurst } from "@/components/StarBurst";
import { EncouragementBanner } from "@/components/EncouragementBanner";
import { sentencesData } from "@/data/gameData";
import { useSpeech } from "@/hooks/useSpeech";
import { useAdaptive } from "@/hooks/useAdaptive";
import { Volume2, RotateCcw } from "lucide-react";

export function SentenceGame({ onHome, score, onWin }: { onHome: () => void; score: number; onWin: () => void }) {
  const [round, setRound] = useState(0);
  const [sentenceData, setSentenceData] = useState(sentencesData[0]);
  const [words, setWords] = useState<string[]>([]);
  const [placed, setPlaced] = useState<string[]>([]);
  const [available, setAvailable] = useState<string[]>([]);
  const [solved, setSolved] = useState(false);
  const [wrongShake, setWrongShake] = useState(false);
  const [encouragement, setEncouragement] = useState("");
  const [encourageTrigger, setEncourageTrigger] = useState(0);
  const { speak } = useSpeech();
  const { selectItem, recordResult, isMastered } = useAdaptive("sentence");

  useEffect(() => { initRound(); }, [round]);

  const initRound = () => {
    const s = selectItem(sentencesData, s => s.text);
    setSentenceData(s);
    const wordList = s.text.split(" ");
    setWords(wordList);
    setPlaced([]);
    setAvailable([...wordList].sort(() => 0.5 - Math.random()));
    setSolved(false);
  };

  const handlePlace = (word: string) => {
    if (solved) return;
    speak(word);
    const newPlaced = [...placed, word];
    setPlaced(newPlaced);
    const idx = available.indexOf(word);
    setAvailable(available.filter((_, i) => i !== idx));

    if (newPlaced.length === words.length) {
      if (newPlaced.join(" ") === sentenceData.text) {
        setSolved(true);
        onWin();
        const { encouragement: msg } = recordResult(sentenceData.text, true);
        setEncouragement(msg);
        setEncourageTrigger(t => t + 1);
        setTimeout(() => speak(`Great job! ${sentenceData.text}`), 500);
      } else {
        recordResult(sentenceData.text, false);
        setWrongShake(true);
        setTimeout(() => {
          setWrongShake(false);
          setAvailable([...words].sort(() => 0.5 - Math.random()));
          setPlaced([]);
          speak("Not quite! Let's try again.");
        }, 800);
      }
    }
  };

  const handleUndo = () => {
    if (placed.length === 0 || solved) return;
    const word = placed[placed.length - 1];
    setPlaced(placed.slice(0, -1));
    setAvailable([...available, word]);
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 50 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -50 }}
      className="flex flex-col items-center flex-1 pt-24 pb-6 px-4"
    >
      <ScoreBar score={score} onHome={onHome} />
      <StarBurst active={solved} />
      <EncouragementBanner message={encouragement} trigger={encourageTrigger} />

      <div className="flex-1 flex flex-col items-center justify-center w-full max-w-3xl gap-8">
        <motion.div
          animate={wrongShake ? { x: [-10, 10, -10, 10, 0] } : {}}
          className="bg-white border-8 border-green-400 rounded-3xl p-8 flex flex-col items-center w-full shadow-lg relative"
        >
          {isMastered(sentenceData.text) && (
            <span className="absolute top-3 right-4 text-2xl" title="Mastered!">🏅</span>
          )}
          <div className="text-7xl mb-6">{sentenceData.emoji}</div>

          <div className="flex flex-wrap justify-center gap-3 min-h-[4rem] mb-4">
            {words.map((_, i) => (
              <div
                key={i}
                className={`h-16 px-6 flex items-center justify-center text-3xl font-display rounded-2xl border-4 ${
                  placed[i]
                    ? "bg-green-100 border-green-400 text-green-800 shadow-sm"
                    : "bg-gray-100 border-gray-300 border-dashed"
                }`}
                style={{ minWidth: "5rem" }}
              >
                {placed[i] || ""}
              </div>
            ))}
          </div>

          <div className="flex gap-4">
            <button
              onClick={() => speak(sentenceData.text)}
              className="bg-green-100 hover:bg-green-200 text-green-700 py-2 px-6 rounded-full flex items-center gap-2 font-bold transition-colors"
            >
              <Volume2 size={20} /> Listen
            </button>
            <button
              onClick={handleUndo}
              disabled={placed.length === 0 || solved}
              className="bg-gray-100 hover:bg-gray-200 text-gray-700 disabled:opacity-50 py-2 px-6 rounded-full flex items-center gap-2 font-bold transition-colors"
            >
              <RotateCcw size={20} /> Undo
            </button>
          </div>
        </motion.div>

        {!solved ? (
          <div className="bg-white/50 backdrop-blur border-4 border-white rounded-3xl p-6 w-full flex flex-wrap justify-center gap-4">
            <AnimatePresence>
              {available.map((word, i) => (
                <motion.button
                  key={`${word}-${i}`}
                  layout
                  initial={{ scale: 0 }} animate={{ scale: 1 }} exit={{ scale: 0 }}
                  whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}
                  onClick={() => handlePlace(word)}
                  className="bg-green-400 text-white text-3xl font-display py-4 px-8 rounded-2xl shadow-[0_6px_0_rgba(22,163,74,1)] border-4 border-white"
                >
                  {word}
                </motion.button>
              ))}
            </AnimatePresence>
          </div>
        ) : (
          <motion.button
            initial={{ scale: 0 }} animate={{ scale: 1 }}
            whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}
            onClick={() => setRound(r => r + 1)}
            className="bg-orange-400 text-white text-3xl font-display py-4 px-12 rounded-full shadow-[0_6px_0_rgba(234,88,12,1)] border-4 border-white"
          >
            Next Sentence! ➔
          </motion.button>
        )}
      </div>
    </motion.div>
  );
}
